package custom.fixers;

import custom.checkers.DuplicateAtomMapChecker;
import chemaxon.fixers.FixerInfo;
import chemaxon.fixers.FixesExternal;
import chemaxon.fixers.RemoveAtomMapFixer;

@FixesExternal(DuplicateAtomMapChecker.DUPLICATE_ATOM_MAP_CHECKER_ERROR)
@FixerInfo(
	name = "Remove duplicated atom maps",
	description = "Removes duplicated atom maps.",
	actionStringToken = "removeduplicatedmaps")
public class ExternalRemoveAtomMapFixer extends RemoveAtomMapFixer {

}
